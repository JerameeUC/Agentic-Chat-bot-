# Parking FAQ

**How many passes can I buy?** Multiple passes per student are allowed.

**Any parking rules?** No double parking. Handicap violators will be towed.
