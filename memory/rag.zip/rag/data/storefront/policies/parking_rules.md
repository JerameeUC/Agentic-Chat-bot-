# Parking Rules (Graduation Day)

- No double parking.
- Vehicles parked in handicap spaces will be towed.

Display your pass before approaching attendants. Follow posted signage.
