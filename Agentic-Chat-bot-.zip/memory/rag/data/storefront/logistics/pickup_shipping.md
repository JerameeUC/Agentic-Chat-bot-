# Pickup & Shipping

- Shipping: available until 10 days before event (3–5 business days typical).
- Pickup: Student Center Bookstore during the week prior to event.
