# Graduation Day Guide

- Graduates: Arrive 90 minutes early for lineup.
- Guests: Arrive 60 minutes early; allow time for parking.
- Reminder: Formal attire recommended; no muscle shirts; no sagging pants.
