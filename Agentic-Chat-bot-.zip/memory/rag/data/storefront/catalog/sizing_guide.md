# Cap & Gown Sizing (By Height)

Height (inches) | Gown Size
--- | ---
under 60 | XS
60-63 | S
64-67 | M
68-71 | L
72-75 | XL
76+ | XXL

Tip: If between sizes or broad-shouldered, choose the larger size.
