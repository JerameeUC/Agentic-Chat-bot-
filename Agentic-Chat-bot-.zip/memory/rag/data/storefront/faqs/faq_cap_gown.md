# Cap & Gown FAQ

**How do I pick a size?** Choose based on height (see sizing table).

**Is a tassel included?** Yes.

**Shipping?** Available until 10 days before the event, then pickup.
