# General FAQ

**What can I buy here?** Cap & Gown sets and Parking Passes for graduation.

**Can I buy multiple parking passes?** Yes, multiple passes are allowed.

**Can I buy parking without a Cap & Gown?** Yes, sold separately.
