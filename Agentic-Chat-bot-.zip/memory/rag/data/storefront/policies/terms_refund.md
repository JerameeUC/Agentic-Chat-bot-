# Terms, Returns & Exchanges

**Cap & Gown**
- Returns: Unworn items accepted until 3 days before the event.
- Size exchanges allowed through event day (stock permitting).

**Parking Pass**
- Non-refundable after purchase unless event is canceled.
