# Venue Rules

- Formal attire recommended (not required).
- No muscle shirts.
- No sagging pants.
